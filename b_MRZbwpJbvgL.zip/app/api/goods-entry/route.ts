import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

interface GoodsEntry {
  id: number
  article_id: number
  supplier_id: number | null
  kolicina: number
  cijena: number
  datum: string
  napomena: string | null
  created_at: string
  article_naziv: string
  article_sifra: string
  supplier_naziv: string | null
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const search = searchParams.get("search") || ""
    const dateFrom = searchParams.get("dateFrom") || ""
    const dateTo = searchParams.get("dateTo") || ""

    let query = `
      SELECT ge.*, 
             a.naziv as article_naziv, a.sifra as article_sifra,
             s.naziv as supplier_naziv
      FROM goods_entry ge
      JOIN articles a ON ge.article_id = a.id
      LEFT JOIN suppliers s ON ge.supplier_id = s.id
      WHERE 1=1
    `
    const params: (string | number)[] = []

    if (search) {
      query += ` AND (a.naziv LIKE ? OR a.sifra LIKE ?)`
      params.push(`%${search}%`, `%${search}%`)
    }

    if (dateFrom) {
      query += ` AND ge.datum >= ?`
      params.push(dateFrom)
    }

    if (dateTo) {
      query += ` AND ge.datum <= ?`
      params.push(dateTo)
    }

    query += ` ORDER BY ge.created_at DESC`

    const entries = db.prepare(query).all(...params) as GoodsEntry[]

    return NextResponse.json(entries)
  } catch (error) {
    console.error("Goods entry GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const { article_id, supplier_id, kolicina, cijena, datum, napomena } = data

    if (!article_id || !kolicina || !cijena || !datum) {
      return NextResponse.json(
        { error: "Artikal, količina, cijena i datum su obavezni" },
        { status: 400 }
      )
    }

    const result = db
      .prepare(
        `INSERT INTO goods_entry (article_id, supplier_id, kolicina, cijena, datum, napomena)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(article_id, supplier_id || null, kolicina, cijena, datum, napomena || null)

    const entry = db
      .prepare(
        `SELECT ge.*, 
                a.naziv as article_naziv, a.sifra as article_sifra,
                s.naziv as supplier_naziv
         FROM goods_entry ge
         JOIN articles a ON ge.article_id = a.id
         LEFT JOIN suppliers s ON ge.supplier_id = s.id
         WHERE ge.id = ?`
      )
      .get(result.lastInsertRowid)

    return NextResponse.json(entry, { status: 201 })
  } catch (error) {
    console.error("Goods entry POST error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
