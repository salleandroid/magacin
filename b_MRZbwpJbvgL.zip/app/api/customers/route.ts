import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const customers = db.prepare("SELECT * FROM customers ORDER BY naziv ASC").all()
    return NextResponse.json(customers)
  } catch (error) {
    console.error("Customers GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const { naziv, adresa, telefon, email } = data

    if (!naziv) {
      return NextResponse.json({ error: "Naziv je obavezan" }, { status: 400 })
    }

    const result = db
      .prepare("INSERT INTO customers (naziv, adresa, telefon, email) VALUES (?, ?, ?, ?)")
      .run(naziv, adresa || null, telefon || null, email || null)

    const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(result.lastInsertRowid)

    return NextResponse.json(customer, { status: 201 })
  } catch (error) {
    console.error("Customers POST error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
