import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

interface GoodsExit {
  id: number
  article_id: number
  customer_id: number | null
  kolicina: number
  datum: string
  napomena: string | null
  created_at: string
  article_naziv: string
  article_sifra: string
  customer_naziv: string | null
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const search = searchParams.get("search") || ""
    const dateFrom = searchParams.get("dateFrom") || ""
    const dateTo = searchParams.get("dateTo") || ""

    let query = `
      SELECT gx.*, 
             a.naziv as article_naziv, a.sifra as article_sifra,
             c.naziv as customer_naziv
      FROM goods_exit gx
      JOIN articles a ON gx.article_id = a.id
      LEFT JOIN customers c ON gx.customer_id = c.id
      WHERE 1=1
    `
    const params: (string | number)[] = []

    if (search) {
      query += ` AND (a.naziv LIKE ? OR a.sifra LIKE ?)`
      params.push(`%${search}%`, `%${search}%`)
    }

    if (dateFrom) {
      query += ` AND gx.datum >= ?`
      params.push(dateFrom)
    }

    if (dateTo) {
      query += ` AND gx.datum <= ?`
      params.push(dateTo)
    }

    query += ` ORDER BY gx.created_at DESC`

    const exits = db.prepare(query).all(...params) as GoodsExit[]

    return NextResponse.json(exits)
  } catch (error) {
    console.error("Goods exit GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const { article_id, customer_id, kolicina, datum, napomena } = data

    if (!article_id || !kolicina || !datum) {
      return NextResponse.json(
        { error: "Artikal, količina i datum su obavezni" },
        { status: 400 }
      )
    }

    // Check available stock
    const entrySum = (db.prepare(
      "SELECT COALESCE(SUM(kolicina), 0) as total FROM goods_entry WHERE article_id = ?"
    ).get(article_id) as { total: number }).total

    const exitSum = (db.prepare(
      "SELECT COALESCE(SUM(kolicina), 0) as total FROM goods_exit WHERE article_id = ?"
    ).get(article_id) as { total: number }).total

    const availableStock = entrySum - exitSum

    if (kolicina > availableStock) {
      return NextResponse.json(
        { error: `Nedovoljna količina na stanju. Dostupno: ${availableStock}` },
        { status: 400 }
      )
    }

    const result = db
      .prepare(
        `INSERT INTO goods_exit (article_id, customer_id, kolicina, datum, napomena)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(article_id, customer_id || null, kolicina, datum, napomena || null)

    const exit = db
      .prepare(
        `SELECT gx.*, 
                a.naziv as article_naziv, a.sifra as article_sifra,
                c.naziv as customer_naziv
         FROM goods_exit gx
         JOIN articles a ON gx.article_id = a.id
         LEFT JOIN customers c ON gx.customer_id = c.id
         WHERE gx.id = ?`
      )
      .get(result.lastInsertRowid)

    return NextResponse.json(exit, { status: 201 })
  } catch (error) {
    console.error("Goods exit POST error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
