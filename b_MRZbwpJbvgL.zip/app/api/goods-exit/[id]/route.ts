import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    db.prepare("DELETE FROM goods_exit WHERE id = ?").run(id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Goods exit DELETE error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
