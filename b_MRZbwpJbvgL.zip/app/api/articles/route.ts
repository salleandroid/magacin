import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const search = searchParams.get("search") || ""

    let articles
    if (search) {
      articles = db
        .prepare(
          `SELECT * FROM articles 
           WHERE naziv LIKE ? OR sifra LIKE ? OR bar_kod LIKE ?
           ORDER BY created_at DESC`
        )
        .all(`%${search}%`, `%${search}%`, `%${search}%`)
    } else {
      articles = db.prepare("SELECT * FROM articles ORDER BY created_at DESC").all()
    }

    return NextResponse.json(articles)
  } catch (error) {
    console.error("Articles GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const { sifra, naziv, opis, bar_kod, jedinica_mjere } = data

    if (!sifra || !naziv) {
      return NextResponse.json(
        { error: "Šifra i naziv su obavezni" },
        { status: 400 }
      )
    }

    const result = db
      .prepare(
        `INSERT INTO articles (sifra, naziv, opis, bar_kod, jedinica_mjere)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(sifra, naziv, opis || null, bar_kod || null, jedinica_mjere || "kom")

    const article = db.prepare("SELECT * FROM articles WHERE id = ?").get(result.lastInsertRowid)

    return NextResponse.json(article, { status: 201 })
  } catch (error: unknown) {
    console.error("Articles POST error:", error)
    if ((error as { code?: string }).code === "SQLITE_CONSTRAINT_UNIQUE") {
      return NextResponse.json(
        { error: "Artikal sa ovom šifrom već postoji" },
        { status: 400 }
      )
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
