import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    const article = db.prepare("SELECT * FROM articles WHERE id = ?").get(id)

    if (!article) {
      return NextResponse.json({ error: "Artikal nije pronađen" }, { status: 404 })
    }

    return NextResponse.json(article)
  } catch (error) {
    console.error("Article GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    const data = await request.json()
    const { sifra, naziv, opis, bar_kod, jedinica_mjere } = data

    if (!sifra || !naziv) {
      return NextResponse.json(
        { error: "Šifra i naziv su obavezni" },
        { status: 400 }
      )
    }

    db.prepare(
      `UPDATE articles 
       SET sifra = ?, naziv = ?, opis = ?, bar_kod = ?, jedinica_mjere = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).run(sifra, naziv, opis || null, bar_kod || null, jedinica_mjere || "kom", id)

    const article = db.prepare("SELECT * FROM articles WHERE id = ?").get(id)

    return NextResponse.json(article)
  } catch (error: unknown) {
    console.error("Article PUT error:", error)
    if ((error as { code?: string }).code === "SQLITE_CONSTRAINT_UNIQUE") {
      return NextResponse.json(
        { error: "Artikal sa ovom šifrom već postoji" },
        { status: 400 }
      )
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    db.prepare("DELETE FROM articles WHERE id = ?").run(id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Article DELETE error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
