import { NextRequest, NextResponse } from "next/server"
import { login } from "@/lib/auth"
import { cookies } from "next/headers"

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()

    if (!username || !password) {
      return NextResponse.json(
        { success: false, error: "Korisničko ime i lozinka su obavezni" },
        { status: 400 }
      )
    }

    const result = await login(username, password)

    if (result.success && result.token) {
      const cookieStore = await cookies()
      cookieStore.set("auth-token", result.token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 60 * 60 * 24, // 24 hours
        path: "/",
      })

      return NextResponse.json({
        success: true,
        user: result.user,
      })
    }

    return NextResponse.json(
      { success: false, error: result.error },
      { status: 401 }
    )
  } catch (error) {
    console.error("Login API error:", error)
    return NextResponse.json(
      { success: false, error: "Greška na serveru" },
      { status: 500 }
    )
  }
}
