import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

interface Article {
  id: number
  sifra: string
  naziv: string
  jedinica_mjere: string
}

interface GoodsEntry {
  id: number
  article_id: number
  kolicina: number
  cijena: number
  datum: string
  article_naziv: string
  article_sifra: string
  supplier_naziv: string | null
}

interface GoodsExit {
  id: number
  article_id: number
  kolicina: number
  datum: string
  article_naziv: string
  article_sifra: string
  customer_naziv: string | null
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const reportType = searchParams.get("type") || "stock"
    const dateFrom = searchParams.get("dateFrom") || ""
    const dateTo = searchParams.get("dateTo") || ""

    if (reportType === "stock") {
      // Stock report
      const articles = db.prepare("SELECT id, sifra, naziv, jedinica_mjere FROM articles").all() as Article[]
      
      const stockData = articles.map((article) => {
        const entrySum = (db.prepare(
          "SELECT COALESCE(SUM(kolicina), 0) as total FROM goods_entry WHERE article_id = ?"
        ).get(article.id) as { total: number }).total

        const exitSum = (db.prepare(
          "SELECT COALESCE(SUM(kolicina), 0) as total FROM goods_exit WHERE article_id = ?"
        ).get(article.id) as { total: number }).total

        const avgPrice = (db.prepare(
          "SELECT COALESCE(AVG(cijena), 0) as avg FROM goods_entry WHERE article_id = ?"
        ).get(article.id) as { avg: number }).avg

        return {
          sifra: article.sifra,
          naziv: article.naziv,
          jedinica_mjere: article.jedinica_mjere,
          ulaz: entrySum,
          izlaz: exitSum,
          stanje: entrySum - exitSum,
          prosjecna_cijena: avgPrice,
          vrijednost: (entrySum - exitSum) * avgPrice,
        }
      })

      return NextResponse.json({ type: "stock", data: stockData })
    }

    if (reportType === "entries") {
      // Entries report
      let query = `
        SELECT ge.*, 
               a.naziv as article_naziv, a.sifra as article_sifra,
               s.naziv as supplier_naziv
        FROM goods_entry ge
        JOIN articles a ON ge.article_id = a.id
        LEFT JOIN suppliers s ON ge.supplier_id = s.id
        WHERE 1=1
      `
      const params: string[] = []

      if (dateFrom) {
        query += ` AND ge.datum >= ?`
        params.push(dateFrom)
      }

      if (dateTo) {
        query += ` AND ge.datum <= ?`
        params.push(dateTo)
      }

      query += ` ORDER BY ge.datum DESC`

      const entries = db.prepare(query).all(...params) as GoodsEntry[]

      return NextResponse.json({ type: "entries", data: entries })
    }

    if (reportType === "exits") {
      // Exits report
      let query = `
        SELECT gx.*, 
               a.naziv as article_naziv, a.sifra as article_sifra,
               c.naziv as customer_naziv
        FROM goods_exit gx
        JOIN articles a ON gx.article_id = a.id
        LEFT JOIN customers c ON gx.customer_id = c.id
        WHERE 1=1
      `
      const params: string[] = []

      if (dateFrom) {
        query += ` AND gx.datum >= ?`
        params.push(dateFrom)
      }

      if (dateTo) {
        query += ` AND gx.datum <= ?`
        params.push(dateTo)
      }

      query += ` ORDER BY gx.datum DESC`

      const exits = db.prepare(query).all(...params) as GoodsExit[]

      return NextResponse.json({ type: "exits", data: exits })
    }

    return NextResponse.json({ error: "Invalid report type" }, { status: 400 })
  } catch (error) {
    console.error("Reports GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
