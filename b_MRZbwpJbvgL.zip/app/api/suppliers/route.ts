import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const suppliers = db.prepare("SELECT * FROM suppliers ORDER BY naziv ASC").all()
    return NextResponse.json(suppliers)
  } catch (error) {
    console.error("Suppliers GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const { naziv, adresa, telefon, email } = data

    if (!naziv) {
      return NextResponse.json({ error: "Naziv je obavezan" }, { status: 400 })
    }

    const result = db
      .prepare("INSERT INTO suppliers (naziv, adresa, telefon, email) VALUES (?, ?, ?, ?)")
      .run(naziv, adresa || null, telefon || null, email || null)

    const supplier = db.prepare("SELECT * FROM suppliers WHERE id = ?").get(result.lastInsertRowid)

    return NextResponse.json(supplier, { status: 201 })
  } catch (error) {
    console.error("Suppliers POST error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
