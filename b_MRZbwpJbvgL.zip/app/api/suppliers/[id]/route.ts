import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    const data = await request.json()
    const { naziv, adresa, telefon, email } = data

    if (!naziv) {
      return NextResponse.json({ error: "Naziv je obavezan" }, { status: 400 })
    }

    db.prepare(
      "UPDATE suppliers SET naziv = ?, adresa = ?, telefon = ?, email = ? WHERE id = ?"
    ).run(naziv, adresa || null, telefon || null, email || null, id)

    const supplier = db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id)

    return NextResponse.json(supplier)
  } catch (error) {
    console.error("Supplier PUT error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    db.prepare("DELETE FROM suppliers WHERE id = ?").run(id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Supplier DELETE error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
