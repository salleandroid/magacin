import { NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

interface Article {
  id: number
  sifra: string
  naziv: string
  jedinica_mjere: string
}

interface StockResult {
  article_id: number
  total_in: number
  total_out: number
}

interface RecentEntry {
  id: number
  article_id: number
  kolicina: number
  cijena: number
  datum: string
  naziv: string
  sifra: string
}

interface RecentExit {
  id: number
  article_id: number
  kolicina: number
  datum: string
  naziv: string
  sifra: string
}

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get total counts
    const articlesCount = (db.prepare("SELECT COUNT(*) as count FROM articles").get() as { count: number }).count
    const suppliersCount = (db.prepare("SELECT COUNT(*) as count FROM suppliers").get() as { count: number }).count
    const customersCount = (db.prepare("SELECT COUNT(*) as count FROM customers").get() as { count: number }).count

    // Get total stock value (sum of entry values minus exit values)
    const totalEntryValue = (db.prepare(
      "SELECT COALESCE(SUM(kolicina * cijena), 0) as total FROM goods_entry"
    ).get() as { total: number }).total

    // Get stock per article
    const articles = db.prepare("SELECT id, sifra, naziv, jedinica_mjere FROM articles").all() as Article[]
    
    const stockData = articles.map((article) => {
      const entrySum = (db.prepare(
        "SELECT COALESCE(SUM(kolicina), 0) as total FROM goods_entry WHERE article_id = ?"
      ).get(article.id) as { total: number }).total

      const exitSum = (db.prepare(
        "SELECT COALESCE(SUM(kolicina), 0) as total FROM goods_exit WHERE article_id = ?"
      ).get(article.id) as { total: number }).total

      return {
        id: article.id,
        sifra: article.sifra,
        naziv: article.naziv,
        jedinica_mjere: article.jedinica_mjere,
        ulaz: entrySum,
        izlaz: exitSum,
        stanje: entrySum - exitSum,
      }
    })

    // Get low stock items (less than 10)
    const lowStockItems = stockData.filter((item) => item.stanje > 0 && item.stanje < 10)

    // Get recent entries
    const recentEntries = db.prepare(`
      SELECT ge.*, a.naziv, a.sifra
      FROM goods_entry ge
      JOIN articles a ON ge.article_id = a.id
      ORDER BY ge.created_at DESC
      LIMIT 5
    `).all() as RecentEntry[]

    // Get recent exits
    const recentExits = db.prepare(`
      SELECT gx.*, a.naziv, a.sifra
      FROM goods_exit gx
      JOIN articles a ON gx.article_id = a.id
      ORDER BY gx.created_at DESC
      LIMIT 5
    `).all() as RecentExit[]

    return NextResponse.json({
      stats: {
        articlesCount,
        suppliersCount,
        customersCount,
        totalEntryValue,
      },
      stockData,
      lowStockItems,
      recentEntries,
      recentExits,
    })
  } catch (error) {
    console.error("Dashboard GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
