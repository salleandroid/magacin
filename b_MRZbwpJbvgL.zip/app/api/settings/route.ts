import { NextRequest, NextResponse } from "next/server"
import db from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

interface Settings {
  id: number
  company_name: string
  company_logo: string | null
  address: string | null
  phone: string | null
  email: string | null
}

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const settings = db.prepare("SELECT * FROM settings WHERE id = 1").get() as Settings

    return NextResponse.json(settings)
  } catch (error) {
    console.error("Settings GET error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const { company_name, company_logo, address, phone, email } = data

    db.prepare(
      `UPDATE settings 
       SET company_name = ?, company_logo = ?, address = ?, phone = ?, email = ?
       WHERE id = 1`
    ).run(
      company_name || "Moja Firma",
      company_logo || null,
      address || null,
      phone || null,
      email || null
    )

    const settings = db.prepare("SELECT * FROM settings WHERE id = 1").get()

    return NextResponse.json(settings)
  } catch (error) {
    console.error("Settings PUT error:", error)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
