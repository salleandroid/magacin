"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { FileText, Download, Loader2 } from "lucide-react"
import { jsPDF } from "jspdf"
import autoTable from "jspdf-autotable"

interface Settings {
  company_name: string
  company_logo: string | null
  address: string | null
  phone: string | null
  email: string | null
}

interface StockItem {
  sifra: string
  naziv: string
  jedinica_mjere: string
  ulaz: number
  izlaz: number
  stanje: number
  prosjecna_cijena: number
  vrijednost: number
}

interface EntryItem {
  datum: string
  article_sifra: string
  article_naziv: string
  supplier_naziv: string | null
  kolicina: number
  cijena: number
}

interface ExitItem {
  datum: string
  article_sifra: string
  article_naziv: string
  customer_naziv: string | null
  kolicina: number
}

type ReportData = StockItem[] | EntryItem[] | ExitItem[]

export default function ReportsPage() {
  const [reportType, setReportType] = useState("stock")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [reportData, setReportData] = useState<ReportData>([])
  const [settings, setSettings] = useState<Settings | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings")
        const data = await response.json()
        setSettings(data)
      } catch (error) {
        console.error("Error fetching settings:", error)
      }
    }
    fetchSettings()
  }, [])

  const fetchReport = async () => {
    setIsLoading(true)
    try {
      const params = new URLSearchParams()
      params.append("type", reportType)
      if (dateFrom) params.append("dateFrom", dateFrom)
      if (dateTo) params.append("dateTo", dateTo)

      const response = await fetch(`/api/reports?${params.toString()}`)
      const result = await response.json()
      setReportData(result.data || [])
    } catch (error) {
      console.error("Error fetching report:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchReport()
  }, [reportType, dateFrom, dateTo])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("bs-BA", {
      style: "currency",
      currency: "BAM",
    }).format(value)
  }

  const generatePDF = async () => {
    setIsGenerating(true)
    
    try {
      const doc = new jsPDF()
      const pageWidth = doc.internal.pageSize.getWidth()
      
      // Header
      doc.setFontSize(20)
      doc.setFont("helvetica", "bold")
      doc.text(settings?.company_name || "Magacin", pageWidth / 2, 20, { align: "center" })
      
      if (settings?.address) {
        doc.setFontSize(10)
        doc.setFont("helvetica", "normal")
        doc.text(settings.address, pageWidth / 2, 28, { align: "center" })
      }
      
      if (settings?.phone || settings?.email) {
        doc.setFontSize(10)
        const contactInfo = [settings?.phone, settings?.email].filter(Boolean).join(" | ")
        doc.text(contactInfo, pageWidth / 2, 34, { align: "center" })
      }

      // Report title
      doc.setFontSize(14)
      doc.setFont("helvetica", "bold")
      let reportTitle = ""
      if (reportType === "stock") reportTitle = "IZVJEŠTAJ O STANJU ZALIHA"
      else if (reportType === "entries") reportTitle = "IZVJEŠTAJ O ULAZU ROBE"
      else if (reportType === "exits") reportTitle = "IZVJEŠTAJ O IZLAZU ROBE"
      
      doc.text(reportTitle, pageWidth / 2, 45, { align: "center" })

      // Date range
      doc.setFontSize(10)
      doc.setFont("helvetica", "normal")
      const dateRange = dateFrom || dateTo 
        ? `Period: ${dateFrom || "..."} - ${dateTo || "..."}`
        : `Datum izvještaja: ${new Date().toLocaleDateString("bs-BA")}`
      doc.text(dateRange, pageWidth / 2, 52, { align: "center" })

      // Table data
      let tableData: (string | number)[][] = []
      let tableHeaders: string[] = []

      if (reportType === "stock") {
        tableHeaders = ["Šifra", "Naziv", "Jed.", "Ulaz", "Izlaz", "Stanje", "Prosj. cijena", "Vrijednost"]
        tableData = (reportData as StockItem[]).map((item) => [
          item.sifra,
          item.naziv,
          item.jedinica_mjere,
          item.ulaz.toString(),
          item.izlaz.toString(),
          item.stanje.toString(),
          formatCurrency(item.prosjecna_cijena),
          formatCurrency(item.vrijednost),
        ])
      } else if (reportType === "entries") {
        tableHeaders = ["Datum", "Šifra", "Naziv", "Dobavljač", "Količina", "Cijena", "Ukupno"]
        tableData = (reportData as EntryItem[]).map((item) => [
          item.datum,
          item.article_sifra,
          item.article_naziv,
          item.supplier_naziv || "-",
          item.kolicina.toString(),
          formatCurrency(item.cijena),
          formatCurrency(item.kolicina * item.cijena),
        ])
      } else if (reportType === "exits") {
        tableHeaders = ["Datum", "Šifra", "Naziv", "Kupac", "Količina"]
        tableData = (reportData as ExitItem[]).map((item) => [
          item.datum,
          item.article_sifra,
          item.article_naziv,
          item.customer_naziv || "-",
          item.kolicina.toString(),
        ])
      }

      autoTable(doc, {
        head: [tableHeaders],
        body: tableData,
        startY: 60,
        styles: {
          fontSize: 8,
          cellPadding: 2,
        },
        headStyles: {
          fillColor: [41, 128, 185],
          textColor: 255,
          fontStyle: "bold",
        },
        alternateRowStyles: {
          fillColor: [245, 245, 245],
        },
      })

      // Footer with totals for stock report
      if (reportType === "stock") {
        const totalValue = (reportData as StockItem[]).reduce((sum, item) => sum + item.vrijednost, 0)
        const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY || 60
        doc.setFontSize(12)
        doc.setFont("helvetica", "bold")
        doc.text(`Ukupna vrijednost zaliha: ${formatCurrency(totalValue)}`, 14, finalY + 10)
      }

      // Save PDF
      const fileName = `izvjestaj-${reportType}-${new Date().toISOString().split("T")[0]}.pdf`
      doc.save(fileName)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const renderTable = () => {
    if (reportType === "stock") {
      const data = reportData as StockItem[]
      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Šifra</TableHead>
              <TableHead>Naziv</TableHead>
              <TableHead>Jedinica</TableHead>
              <TableHead className="text-right">Ulaz</TableHead>
              <TableHead className="text-right">Izlaz</TableHead>
              <TableHead className="text-right">Stanje</TableHead>
              <TableHead className="text-right">Prosj. cijena</TableHead>
              <TableHead className="text-right">Vrijednost</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length > 0 ? (
              <>
                {data.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-mono">{item.sifra}</TableCell>
                    <TableCell>{item.naziv}</TableCell>
                    <TableCell>{item.jedinica_mjere}</TableCell>
                    <TableCell className="text-right text-green-600">+{item.ulaz}</TableCell>
                    <TableCell className="text-right text-red-600">-{item.izlaz}</TableCell>
                    <TableCell className="text-right font-semibold">{item.stanje}</TableCell>
                    <TableCell className="text-right">{formatCurrency(item.prosjecna_cijena)}</TableCell>
                    <TableCell className="text-right font-semibold">{formatCurrency(item.vrijednost)}</TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-muted/50 font-bold">
                  <TableCell colSpan={7} className="text-right">Ukupna vrijednost:</TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(data.reduce((sum, item) => sum + item.vrijednost, 0))}
                  </TableCell>
                </TableRow>
              </>
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-muted-foreground">
                  Nema podataka
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      )
    }

    if (reportType === "entries") {
      const data = reportData as EntryItem[]
      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Datum</TableHead>
              <TableHead>Šifra</TableHead>
              <TableHead>Naziv</TableHead>
              <TableHead>Dobavljač</TableHead>
              <TableHead className="text-right">Količina</TableHead>
              <TableHead className="text-right">Cijena</TableHead>
              <TableHead className="text-right">Ukupno</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length > 0 ? (
              <>
                {data.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.datum}</TableCell>
                    <TableCell className="font-mono">{item.article_sifra}</TableCell>
                    <TableCell>{item.article_naziv}</TableCell>
                    <TableCell className="text-muted-foreground">{item.supplier_naziv || "-"}</TableCell>
                    <TableCell className="text-right text-green-600">+{item.kolicina}</TableCell>
                    <TableCell className="text-right">{formatCurrency(item.cijena)}</TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatCurrency(item.kolicina * item.cijena)}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-muted/50 font-bold">
                  <TableCell colSpan={6} className="text-right">Ukupno:</TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(data.reduce((sum, item) => sum + (item.kolicina * item.cijena), 0))}
                  </TableCell>
                </TableRow>
              </>
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground">
                  Nema podataka za odabrani period
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      )
    }

    if (reportType === "exits") {
      const data = reportData as ExitItem[]
      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Datum</TableHead>
              <TableHead>Šifra</TableHead>
              <TableHead>Naziv</TableHead>
              <TableHead>Kupac</TableHead>
              <TableHead className="text-right">Količina</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length > 0 ? (
              <>
                {data.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.datum}</TableCell>
                    <TableCell className="font-mono">{item.article_sifra}</TableCell>
                    <TableCell>{item.article_naziv}</TableCell>
                    <TableCell className="text-muted-foreground">{item.customer_naziv || "-"}</TableCell>
                    <TableCell className="text-right text-red-600">-{item.kolicina}</TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-muted/50 font-bold">
                  <TableCell colSpan={4} className="text-right">Ukupna količina:</TableCell>
                  <TableCell className="text-right">
                    {data.reduce((sum, item) => sum + item.kolicina, 0)}
                  </TableCell>
                </TableRow>
              </>
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground">
                  Nema podataka za odabrani period
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      )
    }

    return null
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Izvještaji</h1>
          <p className="text-muted-foreground">Generisanje izvještaja i PDF dokumenata</p>
        </div>
        <Button onClick={generatePDF} disabled={isGenerating || reportData.length === 0}>
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generisanje...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Izvezi u PDF
            </>
          )}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Parametri izvještaja
          </CardTitle>
          <CardDescription>Odaberite tip izvještaja i period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-end gap-4">
            <div className="space-y-2 min-w-[200px]">
              <Label>Tip izvještaja</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stock">Stanje zaliha</SelectItem>
                  <SelectItem value="entries">Ulaz robe</SelectItem>
                  <SelectItem value="exits">Izlaz robe</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Datum od</Label>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Datum do</Label>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </div>
            <Button variant="outline" onClick={() => { setDateFrom(""); setDateTo(""); }}>
              Resetuj filtere
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            {reportType === "stock" && "Stanje zaliha"}
            {reportType === "entries" && "Ulaz robe"}
            {reportType === "exits" && "Izlaz robe"}
          </CardTitle>
          <CardDescription>
            {dateFrom || dateTo
              ? `Period: ${dateFrom || "..."} - ${dateTo || "..."}`
              : "Svi podaci"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            renderTable()
          )}
        </CardContent>
      </Card>
    </div>
  )
}
