"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, Trash2, Loader2, PackagePlus } from "lucide-react"

interface GoodsEntry {
  id: number
  article_id: number
  supplier_id: number | null
  kolicina: number
  cijena: number
  datum: string
  napomena: string | null
  article_naziv: string
  article_sifra: string
  supplier_naziv: string | null
}

interface Article {
  id: number
  sifra: string
  naziv: string
}

interface Supplier {
  id: number
  naziv: string
}

export default function GoodsEntryPage() {
  const [entries, setEntries] = useState<GoodsEntry[]>([])
  const [articles, setArticles] = useState<Article[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [deletingEntry, setDeletingEntry] = useState<GoodsEntry | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    article_id: "",
    supplier_id: "",
    kolicina: "",
    cijena: "",
    datum: new Date().toISOString().split("T")[0],
    napomena: "",
  })
  const [error, setError] = useState("")

  const fetchEntries = async () => {
    try {
      const params = new URLSearchParams()
      if (search) params.append("search", search)
      if (dateFrom) params.append("dateFrom", dateFrom)
      if (dateTo) params.append("dateTo", dateTo)

      const response = await fetch(`/api/goods-entry?${params.toString()}`)
      const data = await response.json()
      setEntries(data)
    } catch (error) {
      console.error("Error fetching entries:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchArticlesAndSuppliers = async () => {
    try {
      const [articlesRes, suppliersRes] = await Promise.all([
        fetch("/api/articles"),
        fetch("/api/suppliers"),
      ])
      const [articlesData, suppliersData] = await Promise.all([
        articlesRes.json(),
        suppliersRes.json(),
      ])
      setArticles(articlesData)
      setSuppliers(suppliersData)
    } catch (error) {
      console.error("Error fetching data:", error)
    }
  }

  useEffect(() => {
    fetchEntries()
    fetchArticlesAndSuppliers()
  }, [search, dateFrom, dateTo])

  const openCreateDialog = () => {
    setFormData({
      article_id: "",
      supplier_id: "",
      kolicina: "",
      cijena: "",
      datum: new Date().toISOString().split("T")[0],
      napomena: "",
    })
    setError("")
    setIsDialogOpen(true)
  }

  const openDeleteDialog = (entry: GoodsEntry) => {
    setDeletingEntry(entry)
    setIsDeleteDialogOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSaving(true)

    try {
      const response = await fetch("/api/goods-entry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          article_id: parseInt(formData.article_id),
          supplier_id: formData.supplier_id ? parseInt(formData.supplier_id) : null,
          kolicina: parseFloat(formData.kolicina),
          cijena: parseFloat(formData.cijena),
          datum: formData.datum,
          napomena: formData.napomena || null,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Greška prilikom spremanja")
        return
      }

      setIsDialogOpen(false)
      fetchEntries()
    } catch {
      setError("Greška pri povezivanju sa serverom")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deletingEntry) return

    try {
      await fetch(`/api/goods-entry/${deletingEntry.id}`, { method: "DELETE" })
      setIsDeleteDialogOpen(false)
      fetchEntries()
    } catch (error) {
      console.error("Error deleting entry:", error)
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("bs-BA", {
      style: "currency",
      currency: "BAM",
    }).format(value)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Ulaz robe</h1>
          <p className="text-muted-foreground">Evidencija ulaza robe u magacin</p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Novi ulaz
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PackagePlus className="h-5 w-5 text-green-600" />
            Lista ulaza
          </CardTitle>
          <CardDescription>Pregled svih ulaza robe</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Pretraži po nazivu ili šifri..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="whitespace-nowrap">Od:</Label>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-auto"
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="whitespace-nowrap">Do:</Label>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-auto"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Datum</TableHead>
                  <TableHead>Šifra</TableHead>
                  <TableHead>Naziv artikla</TableHead>
                  <TableHead>Dobavljač</TableHead>
                  <TableHead className="text-right">Količina</TableHead>
                  <TableHead className="text-right">Cijena</TableHead>
                  <TableHead className="text-right">Ukupno</TableHead>
                  <TableHead className="w-16">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entries.length > 0 ? (
                  entries.map((entry) => (
                    <TableRow key={entry.id}>
                      <TableCell>{entry.datum}</TableCell>
                      <TableCell className="font-mono">{entry.article_sifra}</TableCell>
                      <TableCell className="font-medium">{entry.article_naziv}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {entry.supplier_naziv || "-"}
                      </TableCell>
                      <TableCell className="text-right text-green-600">+{entry.kolicina}</TableCell>
                      <TableCell className="text-right">{formatCurrency(entry.cijena)}</TableCell>
                      <TableCell className="text-right font-semibold">
                        {formatCurrency(entry.kolicina * entry.cijena)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openDeleteDialog(entry)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground">
                      {search || dateFrom || dateTo
                        ? "Nema rezultata za zadane filtere"
                        : "Nema evidentiranih ulaza"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novi ulaz robe</DialogTitle>
            <DialogDescription>Evidentirajte primljenu robu u magacin</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="article_id">Artikal *</Label>
                <Select
                  value={formData.article_id}
                  onValueChange={(value) => setFormData({ ...formData, article_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Odaberite artikal" />
                  </SelectTrigger>
                  <SelectContent>
                    {articles.map((article) => (
                      <SelectItem key={article.id} value={article.id.toString()}>
                        {article.sifra} - {article.naziv}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="supplier_id">Dobavljač</Label>
                <Select
                  value={formData.supplier_id}
                  onValueChange={(value) => setFormData({ ...formData, supplier_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Odaberite dobavljača (opciono)" />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map((supplier) => (
                      <SelectItem key={supplier.id} value={supplier.id.toString()}>
                        {supplier.naziv}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="kolicina">Količina *</Label>
                  <Input
                    id="kolicina"
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.kolicina}
                    onChange={(e) => setFormData({ ...formData, kolicina: e.target.value })}
                    placeholder="0"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cijena">Cijena (KM) *</Label>
                  <Input
                    id="cijena"
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.cijena}
                    onChange={(e) => setFormData({ ...formData, cijena: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="datum">Datum *</Label>
                <Input
                  id="datum"
                  type="date"
                  value={formData.datum}
                  onChange={(e) => setFormData({ ...formData, datum: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="napomena">Napomena</Label>
                <Textarea
                  id="napomena"
                  value={formData.napomena}
                  onChange={(e) => setFormData({ ...formData, napomena: e.target.value })}
                  placeholder="Opciona napomena"
                  rows={2}
                />
              </div>
              {error && (
                <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                  {error}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Odustani
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Spremanje...
                  </>
                ) : (
                  "Evidentiraj ulaz"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Potvrda brisanja</DialogTitle>
            <DialogDescription>
              Jeste li sigurni da želite obrisati ovaj ulaz?
              Ova akcija se ne može poništiti.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Odustani
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Obriši
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
