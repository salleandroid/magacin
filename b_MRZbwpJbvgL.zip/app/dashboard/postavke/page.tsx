"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Settings, Loader2, Save, Building2 } from "lucide-react"

interface CompanySettings {
  id: number
  company_name: string
  company_logo: string | null
  address: string | null
  phone: string | null
  email: string | null
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<CompanySettings | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    company_name: "",
    company_logo: "",
    address: "",
    phone: "",
    email: "",
  })
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings")
        const data = await response.json()
        setSettings(data)
        setFormData({
          company_name: data.company_name || "",
          company_logo: data.company_logo || "",
          address: data.address || "",
          phone: data.phone || "",
          email: data.email || "",
        })
      } catch (error) {
        console.error("Error fetching settings:", error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchSettings()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess(false)
    setIsSaving(true)

    try {
      const response = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Greška prilikom spremanja")
        return
      }

      setSettings(data)
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch {
      setError("Greška pri povezivanju sa serverom")
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-48 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Postavke</h1>
        <p className="text-muted-foreground">Podešavanja sistema i podataka o firmi</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Podaci o firmi
            </CardTitle>
            <CardDescription>
              Ovi podaci se koriste u PDF izvještajima
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="company_name">Naziv firme</Label>
                <Input
                  id="company_name"
                  value={formData.company_name}
                  onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                  placeholder="Naziv vaše firme"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Adresa</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Ulica i broj, Grad, Poštanski broj"
                  rows={2}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+387 xx xxx xxx"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@firma.ba"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="company_logo">URL logotipa (opciono)</Label>
                <Input
                  id="company_logo"
                  value={formData.company_logo}
                  onChange={(e) => setFormData({ ...formData, company_logo: e.target.value })}
                  placeholder="https://..."
                />
                <p className="text-xs text-muted-foreground">
                  Unesite URL slike logotipa za PDF izvještaje
                </p>
              </div>

              {error && (
                <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                  {error}
                </div>
              )}
              {success && (
                <div className="rounded-md bg-green-500/10 p-3 text-sm text-green-600">
                  Postavke su uspješno spremljene!
                </div>
              )}

              <Button type="submit" disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Spremanje...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Spremi postavke
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Informacije o sistemu
            </CardTitle>
            <CardDescription>Verzija i tehničke informacije</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border p-4">
              <p className="text-sm font-medium">Verzija aplikacije</p>
              <p className="text-2xl font-bold">1.0.0</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm font-medium">Baza podataka</p>
              <p className="text-lg">SQLite (lokalno)</p>
              <p className="text-sm text-muted-foreground">database/magacin.db</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm font-medium">Podrazumijevani pristup</p>
              <div className="mt-2 space-y-1">
                <p className="text-sm">
                  <span className="text-muted-foreground">Korisnik:</span>{" "}
                  <code className="rounded bg-muted px-1">admin</code>
                </p>
                <p className="text-sm">
                  <span className="text-muted-foreground">Lozinka:</span>{" "}
                  <code className="rounded bg-muted px-1">admin123</code>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
