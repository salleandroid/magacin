"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, Trash2, Loader2, PackageMinus } from "lucide-react"

interface GoodsExit {
  id: number
  article_id: number
  customer_id: number | null
  kolicina: number
  datum: string
  napomena: string | null
  article_naziv: string
  article_sifra: string
  customer_naziv: string | null
}

interface Article {
  id: number
  sifra: string
  naziv: string
}

interface Customer {
  id: number
  naziv: string
}

export default function GoodsExitPage() {
  const [exits, setExits] = useState<GoodsExit[]>([])
  const [articles, setArticles] = useState<Article[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [deletingExit, setDeletingExit] = useState<GoodsExit | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    article_id: "",
    customer_id: "",
    kolicina: "",
    datum: new Date().toISOString().split("T")[0],
    napomena: "",
  })
  const [error, setError] = useState("")

  const fetchExits = async () => {
    try {
      const params = new URLSearchParams()
      if (search) params.append("search", search)
      if (dateFrom) params.append("dateFrom", dateFrom)
      if (dateTo) params.append("dateTo", dateTo)

      const response = await fetch(`/api/goods-exit?${params.toString()}`)
      const data = await response.json()
      setExits(data)
    } catch (error) {
      console.error("Error fetching exits:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchArticlesAndCustomers = async () => {
    try {
      const [articlesRes, customersRes] = await Promise.all([
        fetch("/api/articles"),
        fetch("/api/customers"),
      ])
      const [articlesData, customersData] = await Promise.all([
        articlesRes.json(),
        customersRes.json(),
      ])
      setArticles(articlesData)
      setCustomers(customersData)
    } catch (error) {
      console.error("Error fetching data:", error)
    }
  }

  useEffect(() => {
    fetchExits()
    fetchArticlesAndCustomers()
  }, [search, dateFrom, dateTo])

  const openCreateDialog = () => {
    setFormData({
      article_id: "",
      customer_id: "",
      kolicina: "",
      datum: new Date().toISOString().split("T")[0],
      napomena: "",
    })
    setError("")
    setIsDialogOpen(true)
  }

  const openDeleteDialog = (exit: GoodsExit) => {
    setDeletingExit(exit)
    setIsDeleteDialogOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSaving(true)

    try {
      const response = await fetch("/api/goods-exit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          article_id: parseInt(formData.article_id),
          customer_id: formData.customer_id ? parseInt(formData.customer_id) : null,
          kolicina: parseFloat(formData.kolicina),
          datum: formData.datum,
          napomena: formData.napomena || null,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Greška prilikom spremanja")
        return
      }

      setIsDialogOpen(false)
      fetchExits()
    } catch {
      setError("Greška pri povezivanju sa serverom")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deletingExit) return

    try {
      await fetch(`/api/goods-exit/${deletingExit.id}`, { method: "DELETE" })
      setIsDeleteDialogOpen(false)
      fetchExits()
    } catch (error) {
      console.error("Error deleting exit:", error)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Izlaz robe</h1>
          <p className="text-muted-foreground">Evidencija izlaza robe iz magacina</p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Novi izlaz
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PackageMinus className="h-5 w-5 text-red-600" />
            Lista izlaza
          </CardTitle>
          <CardDescription>Pregled svih izlaza robe</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Pretraži po nazivu ili šifri..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="whitespace-nowrap">Od:</Label>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-auto"
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="whitespace-nowrap">Do:</Label>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-auto"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Datum</TableHead>
                  <TableHead>Šifra</TableHead>
                  <TableHead>Naziv artikla</TableHead>
                  <TableHead>Kupac</TableHead>
                  <TableHead className="text-right">Količina</TableHead>
                  <TableHead className="w-16">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {exits.length > 0 ? (
                  exits.map((exit) => (
                    <TableRow key={exit.id}>
                      <TableCell>{exit.datum}</TableCell>
                      <TableCell className="font-mono">{exit.article_sifra}</TableCell>
                      <TableCell className="font-medium">{exit.article_naziv}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {exit.customer_naziv || "-"}
                      </TableCell>
                      <TableCell className="text-right text-red-600">-{exit.kolicina}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openDeleteDialog(exit)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      {search || dateFrom || dateTo
                        ? "Nema rezultata za zadane filtere"
                        : "Nema evidentiranih izlaza"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novi izlaz robe</DialogTitle>
            <DialogDescription>Evidentirajte izdatu robu iz magacina</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="article_id">Artikal *</Label>
                <Select
                  value={formData.article_id}
                  onValueChange={(value) => setFormData({ ...formData, article_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Odaberite artikal" />
                  </SelectTrigger>
                  <SelectContent>
                    {articles.map((article) => (
                      <SelectItem key={article.id} value={article.id.toString()}>
                        {article.sifra} - {article.naziv}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="customer_id">Kupac</Label>
                <Select
                  value={formData.customer_id}
                  onValueChange={(value) => setFormData({ ...formData, customer_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Odaberite kupca (opciono)" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.naziv}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="kolicina">Količina *</Label>
                  <Input
                    id="kolicina"
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.kolicina}
                    onChange={(e) => setFormData({ ...formData, kolicina: e.target.value })}
                    placeholder="0"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="datum">Datum *</Label>
                  <Input
                    id="datum"
                    type="date"
                    value={formData.datum}
                    onChange={(e) => setFormData({ ...formData, datum: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="napomena">Napomena</Label>
                <Textarea
                  id="napomena"
                  value={formData.napomena}
                  onChange={(e) => setFormData({ ...formData, napomena: e.target.value })}
                  placeholder="Opciona napomena"
                  rows={2}
                />
              </div>
              {error && (
                <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                  {error}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Odustani
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Spremanje...
                  </>
                ) : (
                  "Evidentiraj izlaz"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Potvrda brisanja</DialogTitle>
            <DialogDescription>
              Jeste li sigurni da želite obrisati ovaj izlaz?
              Ova akcija se ne može poništiti.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Odustani
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Obriši
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
