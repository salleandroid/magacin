"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, Pencil, Trash2, Loader2 } from "lucide-react"

interface Article {
  id: number
  sifra: string
  naziv: string
  opis: string | null
  bar_kod: string | null
  jedinica_mjere: string
  created_at: string
}

const UNITS = ["kom", "kg", "l", "m", "m2", "m3", "par", "set"]

export default function ArticlesPage() {
  const [articles, setArticles] = useState<Article[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [editingArticle, setEditingArticle] = useState<Article | null>(null)
  const [deletingArticle, setDeletingArticle] = useState<Article | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    sifra: "",
    naziv: "",
    opis: "",
    bar_kod: "",
    jedinica_mjere: "kom",
  })
  const [error, setError] = useState("")

  const fetchArticles = async () => {
    try {
      const response = await fetch(`/api/articles?search=${encodeURIComponent(search)}`)
      const data = await response.json()
      setArticles(data)
    } catch (error) {
      console.error("Error fetching articles:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchArticles()
  }, [search])

  const openCreateDialog = () => {
    setEditingArticle(null)
    setFormData({
      sifra: "",
      naziv: "",
      opis: "",
      bar_kod: "",
      jedinica_mjere: "kom",
    })
    setError("")
    setIsDialogOpen(true)
  }

  const openEditDialog = (article: Article) => {
    setEditingArticle(article)
    setFormData({
      sifra: article.sifra,
      naziv: article.naziv,
      opis: article.opis || "",
      bar_kod: article.bar_kod || "",
      jedinica_mjere: article.jedinica_mjere,
    })
    setError("")
    setIsDialogOpen(true)
  }

  const openDeleteDialog = (article: Article) => {
    setDeletingArticle(article)
    setIsDeleteDialogOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSaving(true)

    try {
      const url = editingArticle
        ? `/api/articles/${editingArticle.id}`
        : "/api/articles"
      const method = editingArticle ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Greška prilikom spremanja")
        return
      }

      setIsDialogOpen(false)
      fetchArticles()
    } catch {
      setError("Greška pri povezivanju sa serverom")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deletingArticle) return

    try {
      await fetch(`/api/articles/${deletingArticle.id}`, { method: "DELETE" })
      setIsDeleteDialogOpen(false)
      fetchArticles()
    } catch (error) {
      console.error("Error deleting article:", error)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Artikli</h1>
          <p className="text-muted-foreground">Upravljanje artiklima u magacinu</p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Novi artikal
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista artikala</CardTitle>
          <CardDescription>Pregled i upravljanje svim artiklima</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Pretraži po nazivu, šifri ili bar-kodu..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Šifra</TableHead>
                  <TableHead>Naziv</TableHead>
                  <TableHead>Bar-kod</TableHead>
                  <TableHead>Jedinica</TableHead>
                  <TableHead>Opis</TableHead>
                  <TableHead className="w-24">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {articles.length > 0 ? (
                  articles.map((article) => (
                    <TableRow key={article.id}>
                      <TableCell className="font-mono">{article.sifra}</TableCell>
                      <TableCell className="font-medium">{article.naziv}</TableCell>
                      <TableCell className="font-mono text-muted-foreground">
                        {article.bar_kod || "-"}
                      </TableCell>
                      <TableCell>{article.jedinica_mjere}</TableCell>
                      <TableCell className="max-w-xs truncate text-muted-foreground">
                        {article.opis || "-"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(article)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openDeleteDialog(article)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      {search ? "Nema rezultata pretrage" : "Nema artikala u sistemu"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingArticle ? "Uredi artikal" : "Novi artikal"}
            </DialogTitle>
            <DialogDescription>
              {editingArticle
                ? "Izmijenite podatke o artiklu"
                : "Unesite podatke za novi artikal"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sifra">Šifra *</Label>
                  <Input
                    id="sifra"
                    value={formData.sifra}
                    onChange={(e) => setFormData({ ...formData, sifra: e.target.value })}
                    placeholder="ART001"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bar_kod">Bar-kod</Label>
                  <Input
                    id="bar_kod"
                    value={formData.bar_kod}
                    onChange={(e) => setFormData({ ...formData, bar_kod: e.target.value })}
                    placeholder="1234567890123"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="naziv">Naziv *</Label>
                <Input
                  id="naziv"
                  value={formData.naziv}
                  onChange={(e) => setFormData({ ...formData, naziv: e.target.value })}
                  placeholder="Naziv artikla"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="jedinica_mjere">Jedinica mjere</Label>
                <Select
                  value={formData.jedinica_mjere}
                  onValueChange={(value) => setFormData({ ...formData, jedinica_mjere: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {UNITS.map((unit) => (
                      <SelectItem key={unit} value={unit}>
                        {unit}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="opis">Opis</Label>
                <Textarea
                  id="opis"
                  value={formData.opis}
                  onChange={(e) => setFormData({ ...formData, opis: e.target.value })}
                  placeholder="Opcionalni opis artikla"
                  rows={3}
                />
              </div>
              {error && (
                <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                  {error}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Odustani
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Spremanje...
                  </>
                ) : editingArticle ? (
                  "Spremi izmjene"
                ) : (
                  "Dodaj artikal"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Potvrda brisanja</DialogTitle>
            <DialogDescription>
              Jeste li sigurni da želite obrisati artikal &quot;{deletingArticle?.naziv}&quot;?
              Ova akcija se ne može poništiti.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Odustani
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Obriši
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
