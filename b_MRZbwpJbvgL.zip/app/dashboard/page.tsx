"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Boxes, Truck, Users, TrendingUp, Package, AlertTriangle } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface DashboardData {
  stats: {
    articlesCount: number
    suppliersCount: number
    customersCount: number
    totalEntryValue: number
  }
  stockData: Array<{
    id: number
    sifra: string
    naziv: string
    jedinica_mjere: string
    ulaz: number
    izlaz: number
    stanje: number
  }>
  lowStockItems: Array<{
    id: number
    sifra: string
    naziv: string
    stanje: number
  }>
  recentEntries: Array<{
    id: number
    naziv: string
    sifra: string
    kolicina: number
    cijena: number
    datum: string
  }>
  recentExits: Array<{
    id: number
    naziv: string
    sifra: string
    kolicina: number
    datum: string
  }>
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/dashboard")
        const result = await response.json()
        setData(result)
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="flex h-24 items-center justify-center">
                <div className="h-4 w-24 animate-pulse rounded bg-muted" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("bs-BA", {
      style: "currency",
      currency: "BAM",
    }).format(value)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Pregled stanja magacina</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ukupno artikala</CardTitle>
            <Boxes className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data?.stats.articlesCount || 0}</div>
            <p className="text-xs text-muted-foreground">aktivnih u sistemu</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dobavljači</CardTitle>
            <Truck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data?.stats.suppliersCount || 0}</div>
            <p className="text-xs text-muted-foreground">registrovanih</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kupci</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data?.stats.customersCount || 0}</div>
            <p className="text-xs text-muted-foreground">registrovanih</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ukupna vrijednost</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(data?.stats.totalEntryValue || 0)}
            </div>
            <p className="text-xs text-muted-foreground">ulazna vrijednost</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Low Stock Warning */}
        {data?.lowStockItems && data.lowStockItems.length > 0 && (
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-600">
                <AlertTriangle className="h-5 w-5" />
                Upozorenje - Niske zalihe
              </CardTitle>
              <CardDescription>Artikli sa zalihama manjim od 10 jedinica</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {data.lowStockItems.map((item) => (
                  <Badge key={item.id} variant="outline" className="border-amber-500 text-amber-600">
                    {item.naziv} ({item.stanje})
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stock Table */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Stanje zaliha
            </CardTitle>
            <CardDescription>Pregled svih artikala i njihovih zaliha</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Šifra</TableHead>
                  <TableHead>Naziv</TableHead>
                  <TableHead className="text-right">Ulaz</TableHead>
                  <TableHead className="text-right">Izlaz</TableHead>
                  <TableHead className="text-right">Stanje</TableHead>
                  <TableHead>Jedinica</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data?.stockData && data.stockData.length > 0 ? (
                  data.stockData.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-mono">{item.sifra}</TableCell>
                      <TableCell>{item.naziv}</TableCell>
                      <TableCell className="text-right text-green-600">+{item.ulaz}</TableCell>
                      <TableCell className="text-right text-red-600">-{item.izlaz}</TableCell>
                      <TableCell className="text-right font-semibold">
                        <span className={item.stanje < 10 ? "text-amber-600" : ""}>
                          {item.stanje}
                        </span>
                      </TableCell>
                      <TableCell>{item.jedinica_mjere}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      Nema artikala u sistemu
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Recent Entries */}
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Posljednji ulazi</CardTitle>
            <CardDescription>Nedavno primljena roba</CardDescription>
          </CardHeader>
          <CardContent>
            {data?.recentEntries && data.recentEntries.length > 0 ? (
              <div className="space-y-3">
                {data.recentEntries.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="font-medium">{entry.naziv}</p>
                      <p className="text-sm text-muted-foreground">{entry.datum}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-green-600">+{entry.kolicina}</p>
                      <p className="text-sm text-muted-foreground">{formatCurrency(entry.cijena)}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground">Nema podataka</p>
            )}
          </CardContent>
        </Card>

        {/* Recent Exits */}
        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Posljednji izlazi</CardTitle>
            <CardDescription>Nedavno izdata roba</CardDescription>
          </CardHeader>
          <CardContent>
            {data?.recentExits && data.recentExits.length > 0 ? (
              <div className="space-y-3">
                {data.recentExits.map((exit) => (
                  <div key={exit.id} className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="font-medium">{exit.naziv}</p>
                      <p className="text-sm text-muted-foreground">{exit.datum}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-red-600">-{exit.kolicina}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground">Nema podataka</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
