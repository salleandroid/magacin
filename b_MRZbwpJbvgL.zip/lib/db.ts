import Database from "better-sqlite3"
import path from "path"
import fs from "fs"

// Ensure database directory exists
const dbDir = path.join(process.cwd(), "database")
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true })
}

const dbPath = path.join(dbDir, "magacin.db")
const db = new Database(dbPath)

// Enable foreign keys
db.pragma("foreign_keys = ON")

// Initialize database tables
db.exec(`
  -- Users table for authentication
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Articles table (artikli)
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sifra TEXT UNIQUE NOT NULL,
    naziv TEXT NOT NULL,
    opis TEXT,
    bar_kod TEXT,
    jedinica_mjere TEXT NOT NULL DEFAULT 'kom',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Suppliers table (dobavljači)
  CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    adresa TEXT,
    telefon TEXT,
    email TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Customers table (kupci)
  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    naziv TEXT NOT NULL,
    adresa TEXT,
    telefon TEXT,
    email TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Goods entry table (ulaz robe)
  CREATE TABLE IF NOT EXISTS goods_entry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL,
    supplier_id INTEGER,
    kolicina REAL NOT NULL,
    cijena REAL NOT NULL,
    datum DATE NOT NULL,
    napomena TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
  );

  -- Goods exit table (izlaz robe)
  CREATE TABLE IF NOT EXISTS goods_exit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id INTEGER NOT NULL,
    customer_id INTEGER,
    kolicina REAL NOT NULL,
    datum DATE NOT NULL,
    napomena TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
  );

  -- Company settings table
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_name TEXT DEFAULT 'Moja Firma',
    company_logo TEXT,
    address TEXT,
    phone TEXT,
    email TEXT
  );

  -- Insert default settings if not exists
  INSERT OR IGNORE INTO settings (id, company_name) VALUES (1, 'Moja Firma');
`)

// Create default admin user if not exists
import bcrypt from "bcryptjs"
const adminExists = db.prepare("SELECT id FROM users WHERE username = ?").get("admin")
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync("admin123", 10)
  db.prepare("INSERT INTO users (username, password, full_name) VALUES (?, ?, ?)").run(
    "admin",
    hashedPassword,
    "Administrator"
  )
}

export default db
