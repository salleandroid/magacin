import jwt from "jsonwebtoken"
import bcrypt from "bcryptjs"
import db from "./db"
import { cookies } from "next/headers"

const JWT_SECRET = process.env.JWT_SECRET || "magacin-secret-key-2024"

export interface User {
  id: number
  username: string
  full_name: string | null
}

export interface AuthResult {
  success: boolean
  user?: User
  token?: string
  error?: string
}

export async function login(username: string, password: string): Promise<AuthResult> {
  try {
    const user = db
      .prepare("SELECT id, username, password, full_name FROM users WHERE username = ?")
      .get(username) as { id: number; username: string; password: string; full_name: string | null } | undefined

    if (!user) {
      return { success: false, error: "Korisnik nije pronađen" }
    }

    const isValidPassword = bcrypt.compareSync(password, user.password)
    if (!isValidPassword) {
      return { success: false, error: "Pogrešna lozinka" }
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, full_name: user.full_name },
      JWT_SECRET,
      { expiresIn: "24h" }
    )

    return {
      success: true,
      user: { id: user.id, username: user.username, full_name: user.full_name },
      token,
    }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, error: "Greška prilikom prijave" }
  }
}

export async function verifyToken(token: string): Promise<User | null> {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as User
    return decoded
  } catch {
    return null
  }
}

export async function getCurrentUser(): Promise<User | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("auth-token")?.value
    if (!token) return null
    return verifyToken(token)
  } catch {
    return null
  }
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hashSync(password, 10)
}
